#!/bin/bash
#Courework for CS1420
#Created by: Dom Hackl


if [ $# -eq 0 ]
	then
		echo  "Enter the first and last integers"
		read a b
		echo "the first number is $a and the second is $b"

	for value in $(eval echo {$a..$b})
		do
			if (( $value % 7 == 0 ))
			then
				echo "$value:orange"

			elif (( $value % 11 == 0 ))
			then
				echo "$value:banana"

			elif (( $value % 13 == 0 ))
                        then
                                echo "$value:pear"

			else
				echo "$value"
			fi

		done
	echo "What's with the fruit obsession?"
	exit 1


	elif [ $# -eq 1 ]
	then
		echo "Please enter the second number"
		read c
		echo "the first number is $1 and the second is $c"

	for value in $(eval echo {$1..$c})

		do
			if (( $value % 7 == 0 ))
			then
				echo "$value:orange"

			elif (( $value % 11 == 0 ))
			then
				echo "$value:banana"

			elif (( $value % 13 == 0 ))
                        then
                                echo "$value:pear"

			else
				echo "$value"
			fi

		done
	echo "What's with the fruit obsession?"

	elif [ $# -gt 2 ]
	then
		echo "You have entered too many parameters, only the first two will be used!"
		echo "the first number is $1 and the second is $2"
	for value in $(eval echo {$1..$2})
		do
			if (( $value % 7 == 0 ))
			then
				echo "$value:orange"

			elif (( $value % 11 == 0 ))
			then
				echo "$value:banana"

			elif (( $value % 13 == 0 ))
                	then
                		echo "$value:pear"

			else
				echo "$value"
			fi

		done
	echo "What's with the fruit obsession?"

	elif [ $# -eq 2 ]
	then

	for value in $(eval echo {$1..$2})
		do
			if (( $value % 7 == 0 ))
			then
				echo "$value:orange"

			elif (( $value % 11 == 0 ))
			then
				echo "$value:banana"

			elif (( $value % 13 == 0 ))
                        then
                                echo "$value:pear"

			else
				echo "$value"
			fi

		done
	echo "What's with the fruit obsession?"
fi


